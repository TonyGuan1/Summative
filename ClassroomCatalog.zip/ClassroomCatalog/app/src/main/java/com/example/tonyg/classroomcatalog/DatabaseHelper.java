package com.example.tonyg.classroomcatalog;

/**
 * Created by Tonyg on 1/3/2018.
 */
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "people.db";
    public static final String TABLE_NAME = "Catalog_Table";
    public static final String COL1 = "ID";
    public static final String COL2 = "AUTHOR"; // Author Previously NAME
    public static final String COL3 = "TITLE"; //Title || Previously EMAIL
    public static final String COL4 = "SIGNEDBY"; //Person who signed it out
    public static final String COL5 = "CHECKOUTSTATUS"; //Checkout Status || Previously TVSHOW


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                " AUTHOR TEXT, TITLE TEXT, SIGNEDBY TEXT, CHECKOUTSTATUS TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP IF TABLE EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean addData(String author, String title, String signedOut //String tvShow
    ) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, author);
        contentValues.put(COL3, title);
        contentValues.put(COL4, signedOut);
        //contentValues.put(COL4,tvShow);

        long result = db.insert(TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Cursor showData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        return data;
    }

    public boolean updateData(String id, String author, String title, String signedOut //String tvShow
    ) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, id);
        contentValues.put(COL2, author);
        contentValues.put(COL3, title);
        contentValues.put(COL4, signedOut);
        //contentValues.put(COL5,tvShow);
        db.update(TABLE_NAME, contentValues, "ID = ?", new String[]{id});
        return true;
    }

    public Integer deleteData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "ID = ?", new String[]{id});
    }

    public boolean CheckOut(String id, String tvShow) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL5, "Yes");
        db.update(TABLE_NAME, contentValues, "ID = ?", new String[]{id});
        return true;
    }

    public boolean Return(String id, String tvShow) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL5, "No");
        db.update(TABLE_NAME, contentValues, "ID = ?", new String[]{id});
        return true;
    }

}
