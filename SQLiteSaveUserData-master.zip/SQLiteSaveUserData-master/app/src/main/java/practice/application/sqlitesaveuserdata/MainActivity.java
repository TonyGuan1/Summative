package practice.application.sqlitesaveuserdata;

import android.app.AlertDialog;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper peopleDB;

    Button btnAddData, btnViewData,btnUpdateData,btnDelete,btnCheckout,btnReturn,btnCheck;
    EditText etAuthor, etTitle, etSignedOutBy,etID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        peopleDB = new DatabaseHelper(this);

        etAuthor = (EditText) findViewById(R.id.etEnterAuthor);
        etTitle = (EditText) findViewById(R.id.etEnterTitle);
        etSignedOutBy = (EditText) findViewById(R.id.etEnterSignedOutBy);
        btnAddData = (Button) findViewById(R.id.btnAddData);
        btnViewData = (Button) findViewById(R.id.btnViewData);
        btnUpdateData = (Button) findViewById(R.id.btnUpdateData);
        etID = (EditText) findViewById(R.id.etID);
        btnDelete = (Button) findViewById(R.id.btnDelete);
        btnCheckout=(Button)findViewById(R.id.CheckoutBtn);
        btnReturn = (Button)findViewById(R.id.btnReturn);
        btnCheck = (Button)findViewById(R.id.btnCheck);

        AddData();
        ViewData();
        UpdateData();
        DeleteData();
        Checkout();
        Return();
        Check();
    }

    public void AddData() {
        btnAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String author = etAuthor.getText().toString(); //1
                String title = etTitle.getText().toString(); //2
                String signedOutBy = etSignedOutBy.getText().toString(); //3

                boolean insertData = peopleDB.addData(author, title, signedOutBy);

                if (insertData == true) {
                    Toast.makeText(MainActivity.this, "Data Successfully Inserted!", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, "Something went wrong :(.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void ViewData(){
        btnViewData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor data = peopleDB.showData();

                if (data.getCount() == 0) {
                    display("Error", "No Data Found.");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (data.moveToNext()) {
                    buffer.append("ID: " + data.getString(0) + "\n"); //COL 1
                    buffer.append("Author: " + data.getString(1) + "\n");//COL 2
                    buffer.append("Title: " + data.getString(2) + "\n");//COL 3
                    buffer.append("Singed out By: " + data.getString(3) + "\n"); //COL4
                    buffer.append("Checkedout:" + data.getString(4) + "\n\n"); //COL5

                }
                display("All Stored Data:", buffer.toString());
            }
        });
    }

    public void display(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void UpdateData(){
        btnUpdateData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int temp = etID.getText().toString().length();
                if (temp > 0) {
                    boolean update = peopleDB.updateData(etID.getText().toString(), etAuthor.getText().toString(),
                            etTitle.getText().toString(), etSignedOutBy.getText().toString());
                    if (update == true) {
                        Toast.makeText(MainActivity.this, "Successfully Updated Data!", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Something Went Wrong :(.", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "You Must Enter An ID to Update :(.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void DeleteData(){
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int temp = etID.getText().toString().length();
                if(temp > 0){
                    Integer deleteRow = peopleDB.deleteData(etID.getText().toString());
                    if(deleteRow > 0){
                        Toast.makeText(MainActivity.this, "Successfully Deleted The Data!", Toast.LENGTH_LONG).show();
                    }else{
                        Toast.makeText(MainActivity.this, "Something went wrong :(.", Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(MainActivity.this, "You Must Enter An ID to Delete :(.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    public void Checkout(){
        btnCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int temp = etID.getText().toString().length();
                if (temp > 0) {
                    boolean check = peopleDB.CheckOut(etID.getText().toString(), etSignedOutBy.getText().toString());
                    if (check == true) {

                        Toast.makeText(MainActivity.this, "Successfully Checkedout!", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Something Went Wrong.", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "You Must Enter An ID to Checkout.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    public void Return(){
        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int temp = etID.getText().toString().length();
                if (temp > 0) {
                    boolean Return = peopleDB.Return(etID.getText().toString(), etSignedOutBy.getText().toString());
                    if (Return == true) {Toast.makeText(MainActivity.this, "Successfully Returned!", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Something Went Wrong.", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "You Must Enter An ID to return.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    public void Check(){
        btnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean check = peopleDB.Check(etID.getText(),);

            }
        });

    }

}
